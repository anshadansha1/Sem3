<?php
    $username ="root";
    $password = "";
    $server_name = "localhost";
    $db_name = "db_school";

    $conn = new mysqli($server_name , $username, $password, $db_name);

?>